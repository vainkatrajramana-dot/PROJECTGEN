import { useGetProjectStats, useGetRecentProjects, getGetProjectStatsQueryKey, getGetRecentProjectsQueryKey } from "@/lib/api-hooks";
import { CircuitBoard, Cpu, FileText, TrendingUp, Calendar, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Stats() {
  const { data: stats, isLoading: statsLoading } = useGetProjectStats({
    query: { queryKey: getGetProjectStatsQueryKey() }
  });

  const { data: recent, isLoading: recentLoading } = useGetRecentProjects({
    query: { queryKey: getGetRecentProjectsQueryKey() }
  });

  const statCards = [
    {
      label: "Total Generated",
      value: stats?.total ?? 0,
      icon: FileText,
      gradient: "from-indigo-500/20 to-violet-500/20",
      border: "border-indigo-500/20",
      iconColor: "text-indigo-400",
      glow: "rgba(99,102,241,0.15)",
    },
    {
      label: "Arduino Projects",
      value: stats?.arduinoCount ?? 0,
      icon: CircuitBoard,
      gradient: "from-blue-500/20 to-cyan-500/20",
      border: "border-blue-500/20",
      iconColor: "text-blue-400",
      glow: "rgba(59,130,246,0.15)",
    },
    {
      label: "ESP32 Projects",
      value: stats?.esp32Count ?? 0,
      icon: Cpu,
      gradient: "from-violet-500/20 to-purple-500/20",
      border: "border-violet-500/20",
      iconColor: "text-violet-400",
      glow: "rgba(139,92,246,0.15)",
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.25), rgba(168,85,247,0.25))", border: "1px solid rgba(99,102,241,0.3)" }}>
            <TrendingUp className="w-5 h-5 text-indigo-400" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">Dashboard</h1>
        </div>
        <p className="text-white/40 text-sm md:text-base ml-12">Platform statistics and generation metrics.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="relative rounded-2xl p-6 overflow-hidden"
              style={{
                background: "rgba(15, 18, 35, 0.7)",
                border: "1px solid rgba(255,255,255,0.07)",
                boxShadow: `0 8px 32px ${card.glow}`,
                backdropFilter: "blur(20px)",
              }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${card.gradient} opacity-40`} />
              <div className="absolute top-0 right-0 p-4 opacity-[0.07]">
                <Icon className="w-28 h-28" />
              </div>
              <div className="relative z-10 space-y-3">
                <div className={`flex items-center gap-2 ${card.iconColor}`}>
                  <Icon className="w-4 h-4" />
                  <span className="text-xs font-semibold uppercase tracking-widest text-white/50">{card.label}</span>
                </div>
                <div className="text-5xl font-bold text-white font-mono">
                  {statsLoading ? (
                    <div className="h-12 w-16 bg-white/10 rounded-lg animate-pulse" />
                  ) : card.value}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent activity */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-400" />
            Recent Activity
          </h2>
          <Link href="/history">
            <span className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer transition-colors">
              View all <ArrowRight className="w-3 h-3" />
            </span>
          </Link>
        </div>

        {recentLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 rounded-xl animate-pulse" style={{ background: "rgba(255,255,255,0.04)" }} />
            ))}
          </div>
        ) : recent && recent.length > 0 ? (
          <div className="rounded-2xl overflow-hidden" style={{
            background: "rgba(15, 18, 35, 0.6)",
            border: "1px solid rgba(255,255,255,0.07)",
            backdropFilter: "blur(20px)"
          }}>
            <div className="divide-y divide-white/[0.05]">
              {recent.map((project) => (
                <div key={project.id} className="p-4 flex items-center justify-between hover:bg-white/[0.03] transition-colors group">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.2), rgba(168,85,247,0.2))", border: "1px solid rgba(99,102,241,0.2)" }}>
                      {project.boardType === 'arduino'
                        ? <CircuitBoard className="w-4.5 h-4.5 text-indigo-400" />
                        : <Cpu className="w-4.5 h-4.5 text-violet-400" />}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-white/90 text-sm truncate">{project.topic}</h3>
                      <p className="text-[11px] text-white/35 font-mono uppercase mt-0.5">
                        {project.boardType} · {new Date(project.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <Link href="/history">
                    <span className="text-xs font-medium text-indigo-400/60 group-hover:text-indigo-400 cursor-pointer transition-colors flex items-center gap-1 ml-4 flex-shrink-0">
                      Open <ArrowRight className="w-3 h-3" />
                    </span>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-10 text-center rounded-2xl" style={{
            background: "rgba(15,18,35,0.4)",
            border: "1px dashed rgba(255,255,255,0.08)"
          }}>
            <p className="text-white/30 text-sm">No recent activity. Generate your first project!</p>
          </div>
        )}
      </div>
    </div>
  );
}
