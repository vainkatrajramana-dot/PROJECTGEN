import { useState } from "react";
import { useListProjects, useDeleteProject, getListProjectsQueryKey, getGetRecentProjectsQueryKey, getGetProjectStatsQueryKey } from "@/lib/api-hooks";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { CircuitBoard, Cpu, Trash2, Search, Calendar, Copy, FolderOpen, FileDown, Clock, Download, Filter } from "lucide-react";
import { exportProjectPdf } from "@/lib/export-pdf";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

type Project = {
  id: number;
  topic: string;
  boardType: string;
  difficulty: string;
  overview: string;
  components: string;
  connections: string;
  libraries: string;
  workingPrinciple: string;
  code: string;
  explanation: string;
  troubleshooting: string;
  vivaQuestions: string;
  diagram: string;
  createdAt: string;
};

const DIFFICULTY_STYLE: Record<string, { bg: string; text: string; border: string }> = {
  beginner:     { bg: "rgba(52,211,153,0.12)",  text: "#34d399", border: "rgba(52,211,153,0.22)" },
  intermediate: { bg: "rgba(251,191,36,0.12)",   text: "#fbbf24", border: "rgba(251,191,36,0.22)" },
  advanced:     { bg: "rgba(239,68,68,0.12)",    text: "#f87171", border: "rgba(239,68,68,0.22)" },
};

function DifficultyBadge({ level }: { level: string }) {
  const key = level.toLowerCase();
  const s = DIFFICULTY_STYLE[key] ?? { bg: "rgba(99,102,241,0.12)", text: "#a5b4fc", border: "rgba(99,102,241,0.22)" };
  return (
    <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full"
      style={{ background: s.bg, color: s.text, border: `1px solid ${s.border}` }}>
      {level}
    </span>
  );
}

function parseDifficultyLabel(raw: string): string {
  if (!raw) return "";
  const first = raw.split("\n")[0].trim().toLowerCase();
  return ["beginner", "intermediate", "advanced"].find(d => first.includes(d)) ?? "";
}

export default function History() {
  const [searchTerm, setSearchTerm] = useState("");
  const [boardFilter, setBoardFilter] = useState<"all" | "arduino" | "esp32">("all");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: projects, isLoading } = useListProjects({ query: { queryKey: getListProjectsQueryKey() } });
  const deleteMutation = useDeleteProject();

  const handleDelete = (id: number, e: { stopPropagation: () => void }) => {
    e.stopPropagation();
    deleteMutation.mutate(id, {
      onSuccess: () => {
        toast({ title: "Deleted", description: "Project removed from history." });
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentProjectsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetProjectStatsQueryKey() });
        if (selectedProject?.id === id) setSelectedProject(null);
      },
      onError: (err) => toast({ title: "Failed to delete", description: err.message, variant: "destructive" }),
    });
  };

  const downloadCode = (project: Project) => {
    const ext = project.boardType === "arduino" ? "ino" : "cpp";
    const filename = `${project.topic.replace(/\s+/g, "_").toLowerCase()}.${ext}`;
    const blob = new Blob([project.code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded", description: filename });
  };

  const filteredProjects = (projects ?? []).filter(p => {
    const matchText = p.topic.toLowerCase().includes(searchTerm.toLowerCase()) || p.boardType.toLowerCase().includes(searchTerm.toLowerCase());
    const matchBoard = boardFilter === "all" || p.boardType === boardFilter;
    return matchText && matchBoard;
  });

  const tabs = [
    { value: "overview",        label: "Overview" },
    { value: "components",      label: "Components" },
    { value: "connections",     label: "Connections" },
    { value: "libraries",       label: "Libraries" },
    { value: "working",         label: "How It Works" },
    { value: "diagram",         label: "Circuit" },
    { value: "code",            label: "Code" },
    { value: "explanation",     label: "Explanation" },
    { value: "troubleshooting", label: "Troubleshoot" },
    { value: "viva",            label: "Viva Q&A" },
  ];

  return (
    <div className="space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-500 h-[calc(100vh-5rem)] flex flex-col">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div className="space-y-0.5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(99,102,241,0.18)", border: "1px solid rgba(99,102,241,0.28)" }}>
              <FolderOpen className="w-4 h-4 text-indigo-400" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">Project History</h1>
          </div>
          <p className="text-white/30 text-xs ml-11">
            {projects ? `${projects.length} saved project${projects.length !== 1 ? "s" : ""}` : "Loading…"}
          </p>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          {/* Board filter */}
          <div className="flex rounded-xl overflow-hidden shrink-0" style={{ border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)" }}>
            {(["all", "arduino", "esp32"] as const).map(f => (
              <button key={f} onClick={() => setBoardFilter(f)}
                className="text-[11px] font-semibold uppercase tracking-wide px-3 py-2 transition-all"
                style={{ background: boardFilter === f ? "rgba(99,102,241,0.25)" : "transparent", color: boardFilter === f ? "#a5b4fc" : "rgba(255,255,255,0.35)" }}>
                {f === "all" ? "All" : f}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative flex-1 md:w-60">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/25" />
            <input
              placeholder="Search projects…"
              className="w-full rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-white/25 outline-none transition-all"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-search"
              onFocus={e => { e.target.style.borderColor = "rgba(99,102,241,0.4)"; }}
              onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.08)"; }}
            />
          </div>
        </div>
      </div>

      {/* Project list */}
      <div className="flex-1 overflow-auto min-h-0 rounded-2xl"
        style={{ background: "rgba(10,12,24,0.70)", border: "1px solid rgba(255,255,255,0.06)", backdropFilter: "blur(20px)" }}>
        {isLoading ? (
          <div className="p-5 space-y-3">
            {[1, 2, 3].map(i => <div key={i} className="h-16 rounded-xl animate-pulse" style={{ background: "rgba(255,255,255,0.03)" }} />)}
          </div>
        ) : filteredProjects.length > 0 ? (
          <div className="divide-y divide-white/[0.04]">
            {filteredProjects.map((project) => {
              const diffLabel = parseDifficultyLabel(project.difficulty ?? "");
              return (
                <div key={project.id}
                  className="px-5 py-3.5 cursor-pointer group flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition-all"
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(99,102,241,0.05)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
                  onClick={() => setSelectedProject(project as Project)}
                  data-testid={`card-project-${project.id}`}>
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: "rgba(99,102,241,0.10)", border: "1px solid rgba(99,102,241,0.15)" }}>
                      {project.boardType === "arduino"
                        ? <CircuitBoard className="w-4 h-4 text-indigo-400" />
                        : <Cpu className="w-4 h-4 text-violet-400" />}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-white/80 group-hover:text-white transition-colors text-sm truncate">{project.topic}</h3>
                      <div className="flex flex-wrap items-center gap-2 mt-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded"
                          style={{ background: "rgba(99,102,241,0.10)", color: "#818cf8" }}>{project.boardType}</span>
                        {diffLabel && <DifficultyBadge level={diffLabel.charAt(0).toUpperCase() + diffLabel.slice(1)} />}
                        <span className="flex items-center gap-1 text-[10px] text-white/25 font-mono">
                          <Clock className="w-2.5 h-2.5" />
                          {new Date(project.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 self-end sm:self-auto shrink-0" onClick={e => e.stopPropagation()}>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button className="w-7 h-7 rounded-lg flex items-center justify-center text-white/20 hover:text-red-400 transition-all"
                          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(239,68,68,0.10)"; }}
                          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent style={{ background: "rgba(10,12,26,0.97)", border: "1px solid rgba(255,255,255,0.09)" }}>
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-white">Delete Project?</AlertDialogTitle>
                          <AlertDialogDescription className="text-white/40">
                            Permanently removes "{project.topic}" from your history. This cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="border-white/10 text-white/60 hover:bg-white/[0.04]">Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={(e) => handleDelete(project.id, e as any)} className="bg-red-600 hover:bg-red-700 text-white">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center p-12 text-center space-y-3">
            <FolderOpen className="w-12 h-12 text-white/8" />
            <p className="text-white/25 text-sm">
              {searchTerm || boardFilter !== "all" ? "No matching projects found." : "No saved projects yet."}
            </p>
            {(searchTerm || boardFilter !== "all") && (
              <button onClick={() => { setSearchTerm(""); setBoardFilter("all"); }} className="text-xs text-indigo-400/60 hover:text-indigo-400">
                Clear filters
              </button>
            )}
          </div>
        )}
      </div>

      {/* Detail dialog */}
      <Dialog open={!!selectedProject} onOpenChange={(open) => !open && setSelectedProject(null)}>
        <DialogContent className="max-w-4xl max-h-[92vh] overflow-hidden flex flex-col p-0 gap-0"
          style={{ background: "rgba(9, 10, 22, 0.98)", border: "1px solid rgba(99,102,241,0.18)", boxShadow: "0 25px 80px rgba(0,0,0,0.65)", backdropFilter: "blur(40px)" }}>
          <DialogHeader className="px-6 py-4 border-b border-white/[0.06] shrink-0"
            style={{ background: "rgba(255,255,255,0.018)" }}>
            <div className="flex items-start justify-between gap-4 pr-8">
              <div className="min-w-0">
                <DialogTitle className="text-lg font-bold text-white leading-tight truncate">
                  {selectedProject?.topic}
                </DialogTitle>
                <DialogDescription className="mt-1.5 flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded"
                    style={{ background: "rgba(99,102,241,0.14)", color: "#a5b4fc" }}>
                    {selectedProject?.boardType}
                  </span>
                  {selectedProject && parseDifficultyLabel(selectedProject.difficulty ?? "") && (
                    <DifficultyBadge level={(() => { const d = parseDifficultyLabel(selectedProject.difficulty ?? ""); return d.charAt(0).toUpperCase() + d.slice(1); })()} />
                  )}
                  <span className="flex items-center gap-1 text-[10px] text-white/30 font-mono">
                    <Calendar className="w-3 h-3" />
                    {selectedProject && new Date(selectedProject.createdAt).toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}
                  </span>
                </DialogDescription>
              </div>
              {selectedProject && (
                <div className="flex items-center gap-1.5 shrink-0">
                  <Button size="sm" variant="outline" className="gap-1.5 text-xs border-white/10 bg-white/[0.04] text-white/55 hover:bg-white/[0.08] hover:text-white h-7"
                    onClick={() => downloadCode(selectedProject)}>
                    <Download className="w-3 h-3" /> Code
                  </Button>
                  <Button size="sm" variant="outline" className="gap-1.5 text-xs border-white/10 bg-white/[0.04] text-white/55 hover:bg-white/[0.08] hover:text-white h-7"
                    onClick={() => exportProjectPdf(selectedProject)}>
                    <FileDown className="w-3 h-3" /> PDF
                  </Button>
                </div>
              )}
            </div>
          </DialogHeader>

          <div className="flex-1 overflow-auto">
            {selectedProject && (
              <Tabs defaultValue="overview" className="w-full h-full flex flex-col">
                <div className="border-b border-white/[0.05] px-3 py-1.5 shrink-0 overflow-x-auto" style={{ background: "rgba(255,255,255,0.015)" }}>
                  <TabsList className="bg-transparent gap-0.5">
                    {tabs.map(tab => (
                      <TabsTrigger key={tab.value} value={tab.value}
                        className="text-[11px] font-medium text-white/35 data-[state=active]:text-white data-[state=active]:bg-white/[0.07] rounded-lg px-2.5 py-1.5 transition-all whitespace-nowrap">
                        {tab.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>

                <div className="flex-1 overflow-auto p-6">
                  {/* Plain text tabs */}
                  {[
                    { value: "overview",    content: selectedProject.overview },
                    { value: "components",  content: selectedProject.components },
                    { value: "connections", content: selectedProject.connections },
                    { value: "libraries",   content: selectedProject.libraries },
                    { value: "explanation", content: selectedProject.explanation },
                  ].map(({ value, content }) => (
                    <TabsContent key={value} value={value} className="mt-0 outline-none">
                      <pre className="whitespace-pre-wrap font-sans text-[13px] leading-7 text-white/72 m-0 p-0 border-0 bg-transparent">{content || "(not available)"}</pre>
                    </TabsContent>
                  ))}

                  <TabsContent value="working" className="mt-0 outline-none">
                    <pre className="whitespace-pre-wrap font-sans text-[13px] leading-7 text-white/72 m-0 p-0 border-0 bg-transparent">{selectedProject.workingPrinciple || "(not available)"}</pre>
                  </TabsContent>

                  <TabsContent value="troubleshooting" className="mt-0 outline-none">
                    <pre className="whitespace-pre-wrap font-sans text-[13px] leading-7 text-white/72 m-0 p-0 border-0 bg-transparent">{selectedProject.troubleshooting || "(not available)"}</pre>
                  </TabsContent>

                  <TabsContent value="viva" className="mt-0 outline-none">
                    <pre className="whitespace-pre-wrap font-sans text-[13px] leading-7 text-white/72 m-0 p-0 border-0 bg-transparent">{selectedProject.vivaQuestions || "(not available)"}</pre>
                  </TabsContent>

                  <TabsContent value="diagram" className="mt-0 outline-none">
                    <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(52,211,153,0.16)" }}>
                      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-emerald-900/40" style={{ background: "rgba(4,18,8,0.92)" }}>
                        <span className="text-emerald-400 text-[10px] font-bold uppercase tracking-widest">⬡ Circuit Diagram</span>
                      </div>
                      <div className="overflow-x-auto p-5" style={{ background: "rgba(3,14,6,0.85)" }}>
                        {selectedProject.diagram
                          ? <pre className="font-mono text-[12px] leading-[1.7] text-emerald-300 whitespace-pre m-0">{selectedProject.diagram}</pre>
                          : <p className="font-mono text-[12px] text-emerald-800 italic">No diagram for this project.</p>}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="code" className="mt-0 outline-none">
                    <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
                      <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.05]"
                        style={{ background: "rgba(18,20,38,0.98)" }}>
                        <div className="flex items-center gap-3">
                          <div className="flex gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400/70" />
                            <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                          </div>
                          <span className="text-white/40 text-[11px] font-mono">{selectedProject.boardType === "arduino" ? "sketch.ino" : "main.cpp"}</span>
                          <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded" style={{ background: "rgba(99,102,241,0.13)", color: "#a5b4fc" }}>C++</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button size="sm" variant="ghost" onClick={() => downloadCode(selectedProject)}
                            className="h-6 gap-1 text-white/30 hover:text-white/65 hover:bg-white/[0.05] text-[10px] px-2">
                            <Download className="w-3 h-3" /> Save
                          </Button>
                          <Button size="sm" variant="ghost"
                            onClick={() => { navigator.clipboard.writeText(selectedProject.code); toast({ title: "Copied!" }); }}
                            className="h-6 gap-1 text-white/30 hover:text-white/65 hover:bg-white/[0.05] text-[10px] px-2">
                            <Copy className="w-3 h-3" /> Copy
                          </Button>
                        </div>
                      </div>
                      <div className="overflow-x-auto max-h-[55vh]" style={{ background: "rgba(5,6,15,0.98)" }}>
                        <table className="w-full border-collapse">
                          <tbody>
                            {selectedProject.code.split("\n").map((line, i) => (
                              <tr key={i} className="hover:bg-white/[0.02] group">
                                <td className="select-none text-right text-white/15 text-[11px] font-mono leading-6 pl-4 pr-4 w-10 align-top group-hover:text-white/30">{i + 1}</td>
                                <td className="pl-2 pr-6 font-mono text-[12px] leading-6 text-white/78 whitespace-pre align-top">{line || " "}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
