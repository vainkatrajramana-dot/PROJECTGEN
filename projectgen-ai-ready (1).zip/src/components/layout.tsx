import { Link, useLocation } from "wouter";
import { Cpu, History, BarChart3, TerminalSquare, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Generator", icon: TerminalSquare, desc: "Create new guide" },
    { href: "/history", label: "History", icon: History, desc: "Saved projects" },
    { href: "/stats", label: "Dashboard", icon: BarChart3, desc: "Usage stats" },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Sidebar */}
      <nav
        className="w-full md:w-64 flex-shrink-0 flex flex-col border-b md:border-b-0 md:border-r border-white/[0.06]"
        style={{ background: "rgba(8, 10, 22, 0.85)", backdropFilter: "blur(24px)" }}
      >
        {/* Logo */}
        <div className="p-5 md:p-6 flex items-center gap-3 border-b border-white/[0.05]">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #6366f1, #a855f7)" }}>
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#080a16]" />
          </div>
          <div>
            <span className="font-bold text-[17px] tracking-tight text-white">ProjectGen</span>
            <span className="block text-[10px] text-indigo-400/80 font-medium tracking-widest uppercase">AI · Beta</span>
          </div>
        </div>

        {/* Nav */}
        <div className="flex-1 px-3 py-3 md:py-5 flex flex-row md:flex-col gap-1 overflow-x-auto md:overflow-x-visible">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className="flex-shrink-0 md:block">
                <div
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 md:py-3 rounded-xl transition-all duration-200 cursor-pointer group relative",
                    isActive
                      ? "text-white"
                      : "text-white/50 hover:text-white/80 hover:bg-white/[0.04]"
                  )}
                  style={isActive ? {
                    background: "linear-gradient(135deg, rgba(99,102,241,0.18), rgba(168,85,247,0.12))",
                    boxShadow: "inset 0 0 0 1px rgba(99,102,241,0.25)"
                  } : {}}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 rounded-r-full"
                      style={{ background: "linear-gradient(180deg, #6366f1, #a855f7)" }} />
                  )}
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center transition-all",
                    isActive ? "text-indigo-300" : "text-white/40 group-hover:text-white/60"
                  )}>
                    <Icon className="w-4.5 h-4.5" />
                  </div>
                  <div className="hidden md:block">
                    <div className={cn("text-sm font-medium", isActive ? "text-white" : "")}>{item.label}</div>
                    <div className="text-[11px] text-white/30 mt-0">{item.desc}</div>
                  </div>
                  <span className="md:hidden text-xs font-medium">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Footer badge */}
        <div className="hidden md:flex items-center gap-2 px-4 py-4 border-t border-white/[0.05]">
          <Zap className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-[11px] text-white/30">Powered by OpenAI GPT-4</span>
        </div>
      </nav>

      {/* Main content */}
      <main className="flex-1 overflow-auto min-h-screen">
        <div className="p-4 md:p-8 lg:p-10 max-w-5xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
