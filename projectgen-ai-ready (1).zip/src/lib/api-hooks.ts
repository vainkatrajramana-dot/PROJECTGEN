// React Query hooks replacing @workspace/api-client-react
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  fetchRecentProjects,
  fetchProjectStats,
  fetchListProjects,
  fetchDeleteProject,
  fetchCreateProject,
  type CreateProjectData,
} from "./api-client";

export { 
  getGetRecentProjectsQueryKey,
  getGetProjectStatsQueryKey,
  getListProjectsQueryKey,
  type Project,
  type ProjectStats,
} from "./api-client";

export function useGetRecentProjects(opts?: { query?: { queryKey?: readonly unknown[] } }) {
  return useQuery({
    queryKey: opts?.query?.queryKey ?? ["projects", "recent"],
    queryFn: fetchRecentProjects,
  });
}

export function useGetProjectStats(opts?: { query?: { queryKey?: readonly unknown[] } }) {
  return useQuery({
    queryKey: opts?.query?.queryKey ?? ["projects", "stats"],
    queryFn: fetchProjectStats,
  });
}

export function useListProjects(opts?: { query?: { queryKey?: readonly unknown[] } }) {
  return useQuery({
    queryKey: opts?.query?.queryKey ?? ["projects", "list"],
    queryFn: fetchListProjects,
  });
}

export function useDeleteProject() {
  return useMutation({ mutationFn: (id: number) => fetchDeleteProject(id) });
}

export function useCreateProject() {
  return useMutation({ mutationFn: (vars: { data: CreateProjectData }) => fetchCreateProject(vars.data) });
}
