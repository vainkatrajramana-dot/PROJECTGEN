export function parseProjectResponse(fullResponse: string) {
  const sections = {
    difficulty: "",
    overview: "",
    components: "",
    connections: "",
    libraries: "",
    workingPrinciple: "",
    code: "",
    explanation: "",
    troubleshooting: "",
    vivaQuestions: "",
    diagram: "",
  };

  if (!fullResponse) return sections;

  const parts = fullResponse.split(/^##\s+/m);

  for (const part of parts) {
    if (!part.trim()) continue;

    const lines = part.split("\n");
    const heading = lines[0].trim().toLowerCase();
    const content = lines.slice(1).join("\n").trim();

    if (heading.includes("overview") || heading.includes("description")) {
      sections.overview = content;
    } else if (heading.includes("component") || heading.includes("material") || heading.includes("hardware")) {
      sections.components = content;
    } else if (heading.includes("pin") || heading.includes("connection") || heading.includes("wiring")) {
      sections.connections = content;
    } else if (heading.includes("librar")) {
      sections.libraries = content;
    } else if (heading.includes("working principle") || heading.includes("how it works") || heading.includes("principle")) {
      sections.workingPrinciple = content;
    } else if (heading.includes("code") || heading.includes("program") || heading.includes("sketch")) {
      // Strip markdown code fences
      let cleanCode = content;
      const fenceMatch = cleanCode.match(/^```(?:cpp|c\+\+|arduino|ino)?\n?([\s\S]*?)```\s*$/);
      if (fenceMatch) {
        cleanCode = fenceMatch[1].trim();
      } else if (cleanCode.startsWith("```")) {
        const firstBreak = cleanCode.indexOf("\n");
        if (firstBreak !== -1) cleanCode = cleanCode.substring(firstBreak + 1);
        if (cleanCode.endsWith("```")) cleanCode = cleanCode.substring(0, cleanCode.length - 3).trim();
      }
      sections.code = cleanCode;
    } else if (heading.includes("explanation") || heading.includes("explain")) {
      sections.explanation = content;
    } else if (heading.includes("troubleshoot") || heading.includes("common issue") || heading.includes("debug")) {
      sections.troubleshooting = content;
    } else if (heading.includes("viva") || heading.includes("question") || heading.includes("faq")) {
      sections.vivaQuestions = content;
    } else if (heading.includes("circuit") || heading.includes("diagram") || heading.includes("schematic")) {
      sections.diagram = content;
    } else if (heading.includes("difficulty") || heading.includes("level")) {
      sections.difficulty = content;
    }
  }

  // Extract difficulty from overview if not found in its own section
  if (!sections.difficulty && sections.overview) {
    const diffMatch = sections.overview.match(/\b(beginner|intermediate|advanced)\b/i);
    if (diffMatch) sections.difficulty = diffMatch[1];
  }

  return sections;
}
