// Local API client replacing @workspace/api-client-react
// Calls the backend at VITE_API_URL (set in Vercel env vars) or same-origin /api

const API_BASE = (import.meta.env.VITE_API_URL ?? "").replace(/\/$/, "");

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`API ${path} failed: ${res.status} ${text}`);
  }
  return res.json() as Promise<T>;
}

// ── Types ──────────────────────────────────────────────────────────────────────

export interface Project {
  id: number;
  topic: string;
  boardType: "arduino" | "esp32" | string;
  difficulty?: string;
  overview?: string;
  components?: string;
  connections?: string;
  libraries?: string;
  workingPrinciple?: string;
  diagram?: string;
  code?: string;
  explanation?: string;
  troubleshooting?: string;
  vivaQuestions?: string;
  createdAt: string;
}

export interface ProjectStats {
  total: number;
  arduinoCount: number;
  esp32Count: number;
}

export type CreateProjectData = Omit<Project, "id" | "createdAt">;

// ── Query key helpers ──────────────────────────────────────────────────────────

export const getGetRecentProjectsQueryKey = () => ["projects", "recent"] as const;
export const getGetProjectStatsQueryKey  = () => ["projects", "stats"]  as const;
export const getListProjectsQueryKey     = () => ["projects", "list"]   as const;

// ── Raw fetchers ───────────────────────────────────────────────────────────────

export const fetchRecentProjects = () => apiFetch<Project[]>("/projects/recent");
export const fetchProjectStats   = () => apiFetch<ProjectStats>("/projects/stats");
export const fetchListProjects   = () => apiFetch<Project[]>("/projects");
export const fetchDeleteProject  = (id: number) =>
  apiFetch<void>(`/projects/${id}`, { method: "DELETE" });
export const fetchCreateProject  = (data: CreateProjectData) =>
  apiFetch<Project>("/projects", { method: "POST", body: JSON.stringify(data) });
