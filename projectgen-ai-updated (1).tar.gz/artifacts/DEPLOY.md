# Deployment Guide

## Files Added
- `api-server/Dockerfile` — Docker config for the backend
- `projectgen-ai/Dockerfile` — Docker config for the frontend
- `api-server/.env.example` — Environment variable template
- `render.yaml` — Render.com deployment config

## Environment Variables (add in Render dashboard)

| Variable | Value |
|---|---|
| `PORT` | `3000` |
| `NODE_ENV` | `production` |
| `LOG_LEVEL` | `info` |
| `OPENAI_API_KEY` | Get from https://platform.openai.com/api-keys |
| `DATABASE_URL` | Get free DB from https://neon.tech |

## Steps to Deploy on Render

1. Push this project to GitHub
2. Go to https://render.com → New → Web Service
3. Connect your GitHub repo
4. Set **Root Directory** to `api-server`
5. Set **Environment** to `Docker`
6. Add all environment variables above
7. Click Deploy

## Free Database (Neon.tech)
1. Go to https://neon.tech and sign up free
2. Create a new project
3. Copy the connection string
4. Paste it as `DATABASE_URL` in Render
