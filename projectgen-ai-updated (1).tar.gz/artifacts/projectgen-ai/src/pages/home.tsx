import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { useCreateProject, useGetRecentProjects, getGetRecentProjectsQueryKey, getGetProjectStatsQueryKey, getListProjectsQueryKey } from "@workspace/api-client-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Copy, Loader2, CircuitBoard, Cpu, ChevronRight, FileText, History, FileDown, Sparkles, Zap, Download, BookOpen, Wrench, Lightbulb, HelpCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { parseProjectResponse } from "@/lib/parse-stream";
import { exportProjectPdf } from "@/lib/export-pdf";
import { useQueryClient } from "@tanstack/react-query";

const DIFFICULTY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  beginner:     { bg: "rgba(52,211,153,0.12)",  text: "#34d399", border: "rgba(52,211,153,0.25)" },
  intermediate: { bg: "rgba(251,191,36,0.12)",   text: "#fbbf24", border: "rgba(251,191,36,0.25)" },
  advanced:     { bg: "rgba(239,68,68,0.12)",    text: "#f87171", border: "rgba(239,68,68,0.25)" },
};

const TEMPLATES = [
  "Smart Dustbin",
  "Fire Alarm",
  "Obstacle Avoiding Robot",
  "Home Automation",
  "Weather Station",
  "Water Level Indicator",
  "Smart Irrigation",
  "Smart Parking System",
];

function DifficultyBadge({ level }: { level: string }) {
  const key = level.toLowerCase();
  const style = DIFFICULTY_COLORS[key] ?? { bg: "rgba(99,102,241,0.12)", text: "#a5b4fc", border: "rgba(99,102,241,0.25)" };
  return (
    <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full"
      style={{ background: style.bg, color: style.text, border: `1px solid ${style.border}` }}>
      {level}
    </span>
  );
}

export default function Home() {
  const [topic, setTopic] = useState("");
  const [boardType, setBoardType] = useState<"arduino" | "esp32">("arduino");
  const [isGenerating, setIsGenerating] = useState(false);
  const [parsedSections, setParsedSections] = useState<ReturnType<typeof parseProjectResponse> | null>(null);
  const [savedThisRun, setSavedThisRun] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createProject = useCreateProject();

  const { data: recentProjects, isLoading: isLoadingRecent } = useGetRecentProjects({
    query: { queryKey: getGetRecentProjectsQueryKey() }
  });

  // Auto-save when generation finishes
  useEffect(() => {
    if (!isGenerating && parsedSections && !savedThisRun) {
      setSavedThisRun(true);
      createProject.mutate({ data: { topic, boardType, ...parsedSections } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRecentProjectsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetProjectStatsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
        },
        onError: () => {}
      });
    }
  }, [isGenerating, parsedSections]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      toast({ title: "Topic required", description: "Please enter a project topic.", variant: "destructive" });
      return;
    }
    if (abortControllerRef.current) abortControllerRef.current.abort();
    abortControllerRef.current = new AbortController();

    setIsGenerating(true);
    setParsedSections(null);
    setSavedThisRun(false);
    let currentRaw = "";

    try {
      const response = await fetch("/api/projects/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, boardType }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) throw new Error("Generation request failed");
      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        for (const line of chunk.split("\n")) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(5));
              if (data.done) {
                if (data.fullResponse) {
                  currentRaw = data.fullResponse;
                  setParsedSections(parseProjectResponse(currentRaw));
                }
              } else if (data.content) {
                currentRaw += data.content;
                setParsedSections(parseProjectResponse(currentRaw));
              }
            } catch {}
          }
        }
      }
    } catch (err: any) {
      if (err.name !== "AbortError") {
        toast({ title: "Generation failed", description: err.message, variant: "destructive" });
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const downloadCode = () => {
    if (!parsedSections?.code) return;
    const ext = boardType === "arduino" ? "ino" : "cpp";
    const filename = `${topic.replace(/\s+/g, "_").toLowerCase()}.${ext}`;
    const blob = new Blob([parsedSections.code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Code downloaded", description: filename });
  };

  const copyCode = () => {
    if (parsedSections?.code) {
      navigator.clipboard.writeText(parsedSections.code);
      toast({ title: "Copied!", description: "Code copied to clipboard." });
    }
  };

  const difficulty = parsedSections?.difficulty?.trim().split("\n")[0]?.trim() ?? "";
  const diffKey = difficulty.toLowerCase().replace(/[^a-z]/g, "");
  const diffLabel = ["beginner", "intermediate", "advanced"].find(d => diffKey.includes(d)) ?? "";

  const tabs = [
    { value: "overview",        label: "Overview",       icon: FileText },
    { value: "components",      label: "Components",     icon: CircuitBoard },
    { value: "connections",     label: "Connections",    icon: Zap },
    { value: "libraries",       label: "Libraries",      icon: BookOpen },
    { value: "working",         label: "How It Works",   icon: Lightbulb },
    { value: "diagram",         label: "Circuit",        icon: CircuitBoard },
    { value: "code",            label: "Code",           icon: FileText },
    { value: "explanation",     label: "Explanation",    icon: FileText },
    { value: "troubleshooting", label: "Troubleshoot",   icon: Wrench },
    { value: "viva",            label: "Viva Q&A",       icon: HelpCircle },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold uppercase tracking-widest px-2.5 py-1 rounded-full"
            style={{ background: "rgba(99,102,241,0.15)", color: "#a5b4fc", border: "1px solid rgba(99,102,241,0.25)" }}>
            ✦ AI Generator
          </span>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight gradient-text">New Project Guide</h1>
        <p className="text-white/40 text-sm md:text-base max-w-xl">
          Enter a topic and get a complete engineering notebook — components, code, circuit diagram, troubleshooting, and viva questions.
        </p>
      </div>

      {/* Generator card */}
      <div className="rounded-2xl p-6 md:p-8 space-y-6"
        style={{
          background: "rgba(15, 18, 35, 0.75)",
          border: "1px solid rgba(99,102,241,0.18)",
          boxShadow: "0 8px 40px rgba(99,102,241,0.10)",
          backdropFilter: "blur(24px)",
        }}>
        <form onSubmit={handleGenerate} className="space-y-5">
          {/* Topic input */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold uppercase tracking-widest text-white/40">Project Topic</label>
              <button
                type="button"
                onClick={() => setShowTemplates(v => !v)}
                className="text-xs text-indigo-400/70 hover:text-indigo-300 flex items-center gap-1 transition-colors"
              >
                <Sparkles className="w-3 h-3" />
                {showTemplates ? "Hide templates" : "Quick templates"}
              </button>
            </div>
            <input
              type="text"
              placeholder="e.g. Smart Irrigation System using Soil Moisture Sensor"
              className="w-full rounded-xl px-4 py-3.5 text-sm md:text-base font-medium text-white placeholder:text-white/25 outline-none transition-all"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.10)" }}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              disabled={isGenerating}
              data-testid="input-topic"
              onFocus={e => { e.target.style.borderColor = "rgba(99,102,241,0.5)"; e.target.style.boxShadow = "0 0 0 3px rgba(99,102,241,0.10)"; }}
              onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.10)"; e.target.style.boxShadow = "none"; }}
            />
          </div>

          {/* Template chips */}
          {showTemplates && (
            <div className="flex flex-wrap gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
              {TEMPLATES.map(tmpl => (
                <button
                  key={tmpl}
                  type="button"
                  onClick={() => { setTopic(tmpl); setShowTemplates(false); }}
                  className="text-xs px-3 py-1.5 rounded-lg transition-all font-medium"
                  style={{ background: "rgba(99,102,241,0.12)", color: "#a5b4fc", border: "1px solid rgba(99,102,241,0.20)" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(99,102,241,0.22)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(99,102,241,0.12)"; }}
                >
                  {tmpl}
                </button>
              ))}
            </div>
          )}

          {/* Platform selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-widest text-white/40">Platform</label>
            <div className="grid grid-cols-2 gap-3">
              {(["arduino", "esp32"] as const).map((board) => {
                const isSelected = boardType === board;
                const Icon = board === "arduino" ? CircuitBoard : Cpu;
                return (
                  <button
                    key={board}
                    type="button"
                    disabled={isGenerating}
                    onClick={() => setBoardType(board)}
                    className="relative flex flex-col items-center gap-2 py-4 rounded-xl transition-all duration-200"
                    style={{
                      background: isSelected ? "linear-gradient(135deg, rgba(99,102,241,0.20), rgba(168,85,247,0.15))" : "rgba(255,255,255,0.03)",
                      border: isSelected ? "1px solid rgba(99,102,241,0.45)" : "1px solid rgba(255,255,255,0.08)",
                      boxShadow: isSelected ? "0 0 20px rgba(99,102,241,0.18)" : "none",
                    }}
                  >
                    <Icon className={`w-5 h-5 ${isSelected ? "text-indigo-300" : "text-white/30"}`} />
                    <span className={`text-sm font-semibold ${isSelected ? "text-white" : "text-white/45"}`}>
                      {board === "arduino" ? "Arduino" : "ESP32"}
                    </span>
                    {isSelected && (
                      <div className="absolute top-2 right-2 w-4 h-4 rounded-full flex items-center justify-center"
                        style={{ background: "rgba(99,102,241,0.30)" }}>
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Generate button row */}
          <div className="flex items-center justify-between pt-1">
            <p className="text-xs text-white/25 flex items-center gap-1.5">
              <Zap className="w-3 h-3 text-indigo-400/50" />
              ~20–40 seconds · auto-saved on completion
            </p>
            <button
              type="submit"
              disabled={isGenerating || !topic.trim()}
              className="btn-gradient flex items-center gap-2 px-6 py-2.5 rounded-xl text-white font-semibold text-sm disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none"
              data-testid="button-generate"
            >
              {isGenerating
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating…</>
                : <><Sparkles className="w-4 h-4" /> Generate Guide</>}
            </button>
          </div>
        </form>
      </div>

      {/* Streaming progress */}
      {isGenerating && (
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl animate-in fade-in"
          style={{ background: "rgba(99,102,241,0.07)", border: "1px solid rgba(99,102,241,0.14)" }}>
          <div className="flex gap-1">
            {[0, 1, 2].map(i => (
              <div key={i} className="w-1.5 h-1.5 rounded-full bg-indigo-400"
                style={{ animation: `pulse-dot 1.2s ease-in-out ${i * 0.2}s infinite` }} />
            ))}
          </div>
          <span className="text-xs text-indigo-300/70">AI is building your project — tabs fill as each section arrives…</span>
        </div>
      )}

      {/* Output */}
      {(parsedSections || isGenerating) && (
        <div className="space-y-3 animate-in fade-in duration-700">
          {/* Output header */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                Generated Output
              </h2>
              {!isGenerating && diffLabel && <DifficultyBadge level={diffLabel.charAt(0).toUpperCase() + diffLabel.slice(1)} />}
              {!isGenerating && parsedSections && (
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full text-emerald-400"
                  style={{ background: "rgba(52,211,153,0.08)", border: "1px solid rgba(52,211,153,0.18)" }}>
                  ✓ Auto-saved
                </span>
              )}
            </div>
            {parsedSections && !isGenerating && (
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline"
                  className="gap-1.5 border-white/10 bg-white/[0.04] text-white/60 hover:bg-white/[0.08] hover:text-white text-xs h-8"
                  onClick={downloadCode}>
                  <Download className="w-3 h-3" /> Code .{boardType === "arduino" ? "ino" : "cpp"}
                </Button>
                <Button size="sm" variant="outline"
                  className="gap-1.5 border-white/10 bg-white/[0.04] text-white/60 hover:bg-white/[0.08] hover:text-white text-xs h-8"
                  onClick={() => exportProjectPdf({ topic, boardType, ...parsedSections })}
                  data-testid="button-export-pdf">
                  <FileDown className="w-3 h-3" /> Export PDF
                </Button>
              </div>
            )}
          </div>

          {/* Tabs */}
          <div className="rounded-2xl overflow-hidden"
            style={{ background: "rgba(10, 12, 24, 0.90)", border: "1px solid rgba(99,102,241,0.13)", boxShadow: "0 8px 40px rgba(0,0,0,0.3)" }}>
            <Tabs defaultValue="overview" className="w-full">
              <div className="border-b border-white/[0.06] px-2 py-1.5 overflow-x-auto"
                style={{ background: "rgba(255,255,255,0.015)" }}>
                <TabsList className="bg-transparent gap-0.5">
                  {tabs.map(tab => (
                    <TabsTrigger key={tab.value} value={tab.value}
                      className="text-[11px] font-medium text-white/35 data-[state=active]:text-white data-[state=active]:bg-white/[0.07] rounded-lg px-2.5 py-1.5 transition-all whitespace-nowrap">
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>

              <div className="min-h-[420px] p-6">
                {/* Plain text tabs */}
                {(["overview", "components", "connections", "libraries", "explanation"] as const).map(key => (
                  <TabsContent key={key} value={key} className="mt-0">
                    <pre className="whitespace-pre-wrap font-sans text-[13.5px] leading-7 text-white/75 m-0 p-0 border-0 bg-transparent">
                      {parsedSections?.[key] || <span className="text-white/20 italic">Generating…</span>}
                    </pre>
                  </TabsContent>
                ))}

                <TabsContent value="working" className="mt-0">
                  <pre className="whitespace-pre-wrap font-sans text-[13.5px] leading-7 text-white/75 m-0 p-0 border-0 bg-transparent">
                    {parsedSections?.workingPrinciple || <span className="text-white/20 italic">Generating…</span>}
                  </pre>
                </TabsContent>

                <TabsContent value="troubleshooting" className="mt-0">
                  <pre className="whitespace-pre-wrap font-sans text-[13.5px] leading-7 text-white/75 m-0 p-0 border-0 bg-transparent">
                    {parsedSections?.troubleshooting || <span className="text-white/20 italic">Generating…</span>}
                  </pre>
                </TabsContent>

                <TabsContent value="viva" className="mt-0">
                  <pre className="whitespace-pre-wrap font-sans text-[13.5px] leading-7 text-white/75 m-0 p-0 border-0 bg-transparent">
                    {parsedSections?.vivaQuestions || <span className="text-white/20 italic">Generating…</span>}
                  </pre>
                </TabsContent>

                {/* Circuit diagram */}
                <TabsContent value="diagram" className="mt-0">
                  <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(52,211,153,0.18)" }}>
                    <div className="flex items-center gap-3 px-4 py-2.5 border-b border-emerald-900/40"
                      style={{ background: "rgba(5, 20, 10, 0.92)" }}>
                      <span className="text-emerald-400 text-[11px] font-bold uppercase tracking-widest">⬡ Circuit Diagram</span>
                      <span className="text-emerald-700 text-[11px]">ASCII wiring — AI generated</span>
                    </div>
                    <div className="overflow-x-auto p-5" style={{ background: "rgba(4, 16, 8, 0.85)" }}>
                      {parsedSections?.diagram
                        ? <pre className="font-mono text-[12px] leading-[1.7] text-emerald-300 whitespace-pre m-0">{parsedSections.diagram}</pre>
                        : <p className="font-mono text-[12px] text-emerald-800 italic">{isGenerating ? "Generating circuit diagram…" : "No diagram available."}</p>}
                    </div>
                  </div>
                </TabsContent>

                {/* Code editor */}
                <TabsContent value="code" className="mt-0">
                  <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
                    <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.06]"
                      style={{ background: "rgba(18, 20, 38, 0.98)" }}>
                      <div className="flex items-center gap-3">
                        <div className="flex gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                          <span className="w-2.5 h-2.5 rounded-full bg-yellow-400/70" />
                          <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                        </div>
                        <span className="text-white/45 text-[11px] font-mono">
                          {boardType === "arduino" ? "sketch.ino" : "main.cpp"}
                        </span>
                        <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded"
                          style={{ background: "rgba(99,102,241,0.15)", color: "#a5b4fc" }}>C++</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="ghost" onClick={downloadCode} disabled={!parsedSections?.code || isGenerating}
                          className="h-6 gap-1 text-white/35 hover:text-white/70 hover:bg-white/[0.05] text-[10px] px-2">
                          <Download className="w-3 h-3" /> Save
                        </Button>
                        <Button size="sm" variant="ghost" onClick={copyCode} disabled={!parsedSections?.code || isGenerating}
                          className="h-6 gap-1 text-white/35 hover:text-white/70 hover:bg-white/[0.05] text-[10px] px-2">
                          <Copy className="w-3 h-3" /> Copy
                        </Button>
                      </div>
                    </div>
                    <div className="overflow-x-auto" style={{ background: "rgba(6, 8, 18, 0.98)" }}>
                      {parsedSections?.code ? (
                        <table className="w-full border-collapse">
                          <tbody>
                            {parsedSections.code.split("\n").map((line, i) => (
                              <tr key={i} className="hover:bg-white/[0.02] group">
                                <td className="select-none text-right text-white/15 text-[11px] font-mono leading-6 pl-4 pr-4 w-10 align-top group-hover:text-white/30">
                                  {i + 1}
                                </td>
                                <td className="pl-2 pr-6 font-mono text-[12px] leading-6 text-white/80 whitespace-pre align-top">
                                  {line || " "}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      ) : (
                        <div className="px-6 py-5 font-mono text-[12px] text-white/20 italic">
                          {isGenerating ? "Generating code…" : "No code yet."}
                        </div>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </div>
      )}

      {/* Recent projects */}
      {!parsedSections && !isGenerating && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white/50 flex items-center gap-2">
              <History className="w-3.5 h-3.5 text-indigo-400/60" />
              Recent Projects
            </h2>
            <Link href="/history">
              <span className="text-xs text-indigo-400/50 hover:text-indigo-400 flex items-center gap-1 cursor-pointer transition-colors">
                View all <ChevronRight className="w-3 h-3" />
              </span>
            </Link>
          </div>

          {isLoadingRecent ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[1, 2].map(i => <div key={i} className="h-18 rounded-xl animate-pulse" style={{ background: "rgba(255,255,255,0.03)" }} />)}
            </div>
          ) : recentProjects && recentProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {recentProjects.map((p) => (
                <Link key={p.id} href="/history" className="block group">
                  <div className="p-4 rounded-xl transition-all duration-200 cursor-pointer"
                    style={{ background: "rgba(15,18,35,0.55)", border: "1px solid rgba(255,255,255,0.06)" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(99,102,241,0.28)"; (e.currentTarget as HTMLElement).style.background = "rgba(99,102,241,0.07)"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.06)"; (e.currentTarget as HTMLElement).style.background = "rgba(15,18,35,0.55)"; }}>
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{ background: "rgba(99,102,241,0.14)", border: "1px solid rgba(99,102,241,0.18)" }}>
                          {p.boardType === 'arduino'
                            ? <CircuitBoard className="w-3.5 h-3.5 text-indigo-400" />
                            : <Cpu className="w-3.5 h-3.5 text-violet-400" />}
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-sm text-white/75 group-hover:text-white transition-colors truncate">{p.topic}</p>
                          <p className="text-[10px] font-mono text-white/25 uppercase mt-0.5">{p.boardType}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-indigo-400 transition-colors flex-shrink-0" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 rounded-2xl" style={{ background: "rgba(15,18,35,0.35)", border: "1px dashed rgba(255,255,255,0.06)" }}>
              <p className="text-white/25 text-sm">No recent projects. Generate one above!</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
