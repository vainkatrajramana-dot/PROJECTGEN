import { jsPDF } from "jspdf";
import type { Project } from "@workspace/api-client-react";

type ProjectData = Pick<
  Project,
  "topic" | "boardType" | "difficulty" | "overview" | "components" | "connections" | "libraries" | "workingPrinciple" | "code" | "explanation" | "troubleshooting" | "vivaQuestions" | "diagram"
> & { createdAt?: string };

const PAGE_W = 210;
const PAGE_H = 297;
const MARGIN = 18;
const CONTENT_W = PAGE_W - MARGIN * 2;

const COLORS = {
  brand:    [30,  60, 114] as [number, number, number],
  section:  [15,  40,  80] as [number, number, number],
  body:     [17,  17,  17] as [number, number, number],
  muted:    [100, 110, 130] as [number, number, number],
  codeBg:   [22,  27,  34] as [number, number, number],
  codeText: [230, 237, 243] as [number, number, number],
  divider:  [220, 225, 235] as [number, number, number],
  white:    [255, 255, 255] as [number, number, number],
};

function addPageHeader(doc: jsPDF, topic: string, pageNum: number, totalPages: number) {
  doc.setFillColor(...COLORS.brand);
  doc.rect(0, 0, PAGE_W, 10, "F");
  doc.setTextColor(...COLORS.white);
  doc.setFontSize(7);
  doc.setFont("helvetica", "normal");
  doc.text("ProjectGen AI", MARGIN, 6.5);
  doc.text(`${topic}`, PAGE_W / 2, 6.5, { align: "center" });
  doc.text(`Page ${pageNum} of ${totalPages}`, PAGE_W - MARGIN, 6.5, { align: "right" });
}

function wrapAndMeasure(doc: jsPDF, text: string, maxWidth: number): string[] {
  if (!text) return [];
  return doc.splitTextToSize(text, maxWidth);
}

export function exportProjectPdf(project: ProjectData): void {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  const boardLabel = project.boardType === "esp32" ? "ESP32" : "Arduino";
  const diffLabel = (() => {
    const raw = (project.difficulty ?? "").split("\n")[0].trim().toLowerCase();
    return ["beginner", "intermediate", "advanced"].find(d => raw.includes(d)) ?? "";
  })();
  const sections = [
    { key: "overview",         label: "Project Overview",    content: project.overview },
    { key: "components",       label: "Required Components", content: project.components },
    { key: "connections",      label: "Pin Connections",     content: project.connections },
    { key: "libraries",        label: "Required Libraries",  content: project.libraries },
    { key: "workingPrinciple", label: "Working Principle",   content: project.workingPrinciple },
    { key: "diagram",          label: "Circuit Diagram",     content: project.diagram,            isDiagram: true },
    { key: "code",             label: `${boardLabel} Code`,  content: project.code,               isCode: true },
    { key: "explanation",      label: "Code Explanation",    content: project.explanation },
    { key: "troubleshooting",  label: "Troubleshooting",     content: project.troubleshooting },
    { key: "vivaQuestions",    label: "Viva Q&A",            content: project.vivaQuestions },
  ] as const;

  // ── Cover page ────────────────────────────────────────────────────────────

  // Hero banner
  doc.setFillColor(...COLORS.brand);
  doc.rect(0, 0, PAGE_W, 60, "F");

  // App name
  doc.setTextColor(...COLORS.white);
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.text("ProjectGen AI", MARGIN, 22);

  // Divider line
  doc.setDrawColor(255, 255, 255, 0.4 as any);
  doc.setLineWidth(0.3);
  doc.line(MARGIN, 27, PAGE_W - MARGIN, 27);

  // Topic
  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  const topicLines = wrapAndMeasure(doc, project.topic, CONTENT_W);
  doc.text(topicLines, MARGIN, 37);

  // Board badge
  const badgeY = 52;
  const badgeLabel = project.boardType.toUpperCase();
  doc.setFillColor(255, 255, 255, 0.15 as any);
  doc.roundedRect(MARGIN - 1, badgeY - 4, 28, 6.5, 1, 1, "F");
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.text(badgeLabel, MARGIN + 13, badgeY, { align: "center" });

  // Difficulty badge
  if (diffLabel) {
    const diffColors: Record<string, [number, number, number]> = {
      beginner:     [52, 211, 153],
      intermediate: [251, 191, 36],
      advanced:     [239, 68, 68],
    };
    const dc = diffColors[diffLabel] ?? [99, 102, 241];
    doc.setFillColor(...dc);
    const diffText = diffLabel.charAt(0).toUpperCase() + diffLabel.slice(1);
    doc.roundedRect(MARGIN + 30, badgeY - 4, 32, 6.5, 1, 1, "F");
    doc.setTextColor(15, 15, 20);
    doc.text(diffText, MARGIN + 46, badgeY, { align: "center" });
  }

  // Date
  if (project.createdAt) {
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(200, 210, 230);
    doc.text(new Date(project.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }), PAGE_W - MARGIN, badgeY, { align: "right" });
  }

  // Table of contents
  let y = 75;
  doc.setTextColor(...COLORS.brand);
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text("Contents", MARGIN, y);
  y += 5;
  doc.setDrawColor(...COLORS.brand);
  doc.setLineWidth(0.5);
  doc.line(MARGIN, y, MARGIN + 30, y);
  y += 6;

  sections.forEach((s, i) => {
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...COLORS.body);
    doc.text(`${i + 1}.  ${s.label}`, MARGIN + 4, y);
    y += 6;
  });

  // ── Content pages ─────────────────────────────────────────────────────────

  doc.addPage();
  let page = 2;

  for (const section of sections) {
    const startPage = page;
    y = 18;

    // Section heading bar
    doc.setFillColor(...COLORS.brand);
    doc.roundedRect(MARGIN, y, CONTENT_W, 9, 1.5, 1.5, "F");
    doc.setTextColor(...COLORS.white);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text(section.label, MARGIN + 4, y + 6);
    y += 14;

    if (!section.content) {
      doc.setTextColor(...COLORS.muted);
      doc.setFontSize(9);
      doc.setFont("helvetica", "italic");
      doc.text("(no content)", MARGIN, y);
    } else if ("isDiagram" in section && section.isDiagram) {
      // Diagram block — dark green background, monospace, no line numbers
      const diagramLines = section.content.split("\n");
      const lineH = 4.5;
      const paddingV = 5;
      const paddingH = 6;

      let blockY = y;
      let lineIdx = 0;

      while (lineIdx < diagramLines.length) {
        const availH = PAGE_H - blockY - MARGIN;
        const linesPerPage = Math.floor((availH - paddingV * 2) / lineH);
        const chunk = diagramLines.slice(lineIdx, lineIdx + Math.max(linesPerPage, 1));
        const blockH = chunk.length * lineH + paddingV * 2;

        // Dark green background
        doc.setFillColor(13, 31, 15);
        doc.roundedRect(MARGIN, blockY, CONTENT_W, blockH, 2, 2, "F");

        // Header strip
        doc.setFillColor(10, 50, 20);
        doc.roundedRect(MARGIN, blockY, CONTENT_W, 6, 2, 2, "F");
        doc.rect(MARGIN, blockY + 3, CONTENT_W, 3, "F");
        doc.setTextColor(80, 160, 90);
        doc.setFontSize(6.5);
        doc.setFont("courier", "bold");
        doc.text("⬡  CIRCUIT DIAGRAM  —  ASCII WIRING", MARGIN + paddingH, blockY + 4.5);

        // Diagram text
        doc.setFontSize(7);
        doc.setFont("courier", "normal");
        doc.setTextColor(100, 220, 120);

        chunk.forEach((line, idx) => {
          const lineY = blockY + paddingV + idx * lineH + 3.5;
          const maxChars = 100;
          const displayLine = line.length > maxChars ? line.slice(0, maxChars) : line;
          doc.text(displayLine, MARGIN + paddingH, lineY);
        });

        lineIdx += chunk.length;
        blockY += blockH + 2;

        if (lineIdx < diagramLines.length) {
          doc.addPage();
          page++;
          addPageHeader(doc, project.topic, page, 999);
          blockY = 18;
        }
      }

      y = blockY;
    } else if ("isCode" in section && section.isCode) {
      // Code block
      const codeLines = section.content.split("\n");
      const lineH = 4.5;
      const paddingV = 4;
      const paddingH = 5;
      const numW = 10;

      let blockY = y;
      let lineIdx = 0;

      while (lineIdx < codeLines.length) {
        // Estimate how many lines fit on remaining space
        const availH = PAGE_H - blockY - MARGIN;
        const linesPerPage = Math.floor((availH - paddingV * 2) / lineH);
        const chunk = codeLines.slice(lineIdx, lineIdx + Math.max(linesPerPage, 1));

        const blockH = chunk.length * lineH + paddingV * 2;

        // Dark background
        doc.setFillColor(...COLORS.codeBg);
        doc.roundedRect(MARGIN, blockY, CONTENT_W, blockH, 2, 2, "F");

        // Line numbers gutter
        doc.setFillColor(15, 20, 28);
        doc.rect(MARGIN, blockY, numW, blockH, "F");
        doc.setDrawColor(50, 60, 75);
        doc.setLineWidth(0.3);
        doc.line(MARGIN + numW, blockY, MARGIN + numW, blockY + blockH);

        // Code text
        doc.setFontSize(7);
        doc.setFont("courier", "normal");

        chunk.forEach((line, idx) => {
          const lineY = blockY + paddingV + idx * lineH + 3;
          const absLineNum = lineIdx + idx + 1;

          // Line number
          doc.setTextColor(90, 105, 125);
          doc.text(String(absLineNum), MARGIN + numW - 2, lineY, { align: "right" });

          // Code content — truncate very long lines
          doc.setTextColor(...COLORS.codeText);
          const maxChars = 95;
          const displayLine = line.length > maxChars ? line.slice(0, maxChars) + "…" : line;
          doc.text(displayLine, MARGIN + numW + paddingH, lineY);
        });

        lineIdx += chunk.length;
        blockY += blockH + 2;

        if (lineIdx < codeLines.length) {
          doc.addPage();
          page++;
          addPageHeader(doc, project.topic, page, 999);
          blockY = 18;
        }
      }

      y = blockY;
    } else {
      // Normal text section
      doc.setFontSize(9.5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...COLORS.body);

      const lines = section.content.split("\n");

      for (const rawLine of lines) {
        const wrapped = wrapAndMeasure(doc, rawLine || " ", CONTENT_W);
        for (const wl of wrapped) {
          if (y > PAGE_H - MARGIN - 5) {
            doc.addPage();
            page++;
            addPageHeader(doc, project.topic, page, 999);
            y = 18;
          }
          doc.text(wl, MARGIN, y);
          y += 5;
        }
      }
    }

    // Add a new page for the next section (unless last)
    if (section !== sections[sections.length - 1]) {
      doc.addPage();
      page++;
    }

    void startPage;
  }

  // ── Fix page numbers now that total is known ──────────────────────────────
  const totalPages = doc.getNumberOfPages();
  for (let p = 2; p <= totalPages; p++) {
    doc.setPage(p);
    addPageHeader(doc, project.topic, p, totalPages);
  }

  // Save
  const safeName = project.topic.replace(/[^a-z0-9]/gi, "_").toLowerCase().slice(0, 40);
  doc.save(`projectgen_${safeName}.pdf`);
}
