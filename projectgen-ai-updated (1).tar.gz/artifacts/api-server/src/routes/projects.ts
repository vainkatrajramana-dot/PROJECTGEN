import { Router } from "express";
import { db } from "@workspace/db";
import { projectsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { openai } from "@workspace/integrations-openai-ai-server";
import {
  GenerateProjectBody,
  CreateProjectBody,
  GetProjectParams,
  DeleteProjectParams,
} from "@workspace/api-zod";

const router = Router();

// ── Project templates for common engineering projects ─────────────────────────
const PROJECT_TEMPLATES: Record<string, { hint: string; components: string[]; difficulty: string }> = {
  "smart dustbin": {
    hint: "Use an HC-SR04 ultrasonic sensor to detect hand proximity and a servo motor to open the lid automatically.",
    components: ["HC-SR04 ultrasonic sensor", "SG90 servo motor", "9V battery", "jumper wires"],
    difficulty: "Beginner",
  },
  "fire alarm": {
    hint: "Use an MQ-2 gas/smoke sensor and a flame sensor module. Trigger a buzzer and LED when fire or smoke is detected.",
    components: ["MQ-2 smoke sensor", "flame sensor module", "5V buzzer", "red LED", "220Ω resistor"],
    difficulty: "Beginner",
  },
  "obstacle avoiding robot": {
    hint: "Use HC-SR04 for obstacle detection, L298N motor driver to control two DC motors, and servo for scanning.",
    components: ["HC-SR04 ultrasonic sensor", "L298N motor driver", "2x DC geared motors", "SG90 servo", "chassis kit", "Li-ion battery"],
    difficulty: "Intermediate",
  },
  "home automation": {
    hint: "Use relay modules to control AC appliances via smartphone over WiFi using ESP8266/ESP32 and a mobile app or web interface.",
    components: ["4-channel relay module", "DHT11 sensor", "ESP32 or NodeMCU", "5V power supply"],
    difficulty: "Intermediate",
  },
  "weather station": {
    hint: "Use DHT22 for temperature/humidity, BMP280 for pressure/altitude, and display readings on an OLED or send to a web dashboard.",
    components: ["DHT22 sensor", "BMP280 barometric sensor", "0.96\" OLED display (I2C)", "RTC DS3231 module"],
    difficulty: "Intermediate",
  },
  "water level indicator": {
    hint: "Use float sensors or capacitive water level sensors at multiple heights, indicate levels with LEDs or buzzer alarm at full/empty.",
    components: ["4x float switches or water level sensors", "4x LEDs (different colors)", "buzzer", "220Ω resistors"],
    difficulty: "Beginner",
  },
  "smart irrigation": {
    hint: "Use a soil moisture sensor to auto-trigger a water pump via relay when soil is dry. Add LCD for status display.",
    components: ["capacitive soil moisture sensor", "5V submersible mini pump", "5V relay module", "16x2 LCD with I2C adapter"],
    difficulty: "Intermediate",
  },
  "smart parking system": {
    hint: "Use IR sensors at each parking slot, display slot availability count on LCD, and a servo-controlled barrier gate.",
    components: ["IR obstacle sensors (one per slot)", "16x2 LCD with I2C", "SG90 servo motor", "green/red LEDs per slot"],
    difficulty: "Intermediate",
  },
};

function getTemplateHint(topic: string): string {
  const lowerTopic = topic.toLowerCase();
  for (const [key, tmpl] of Object.entries(PROJECT_TEMPLATES)) {
    if (lowerTopic.includes(key)) {
      return `\n\nKNOWN TEMPLATE HINT for this project:
- Suggested difficulty: ${tmpl.difficulty}
- Core components: ${tmpl.components.join(", ")}
- Implementation guidance: ${tmpl.hint}
Use this as the basis but customize for the exact topic requested.`;
    }
  }
  return "";
}

// ── Routes ────────────────────────────────────────────────────────────────────

router.get("/projects", async (req, res) => {
  const projects = await db.select().from(projectsTable).orderBy(desc(projectsTable.createdAt));
  res.json(projects.map(p => ({ ...p, createdAt: p.createdAt.toISOString() })));
});

router.get("/projects/stats", async (req, res) => {
  const rows = await db.select().from(projectsTable);
  const total = rows.length;
  const arduinoCount = rows.filter(r => r.boardType === "arduino").length;
  const esp32Count = rows.filter(r => r.boardType === "esp32").length;
  res.json({ total, arduinoCount, esp32Count });
});

router.get("/projects/recent", async (req, res) => {
  const projects = await db.select().from(projectsTable).orderBy(desc(projectsTable.createdAt)).limit(5);
  res.json(projects.map(p => ({ ...p, createdAt: p.createdAt.toISOString() })));
});

router.get("/projects/:id", async (req, res) => {
  const parsed = GetProjectParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid project ID" });
  const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parsed.data.id));
  if (!project) return res.status(404).json({ error: "Project not found" });
  res.json({ ...project, createdAt: project.createdAt.toISOString() });
});

router.post("/projects", async (req, res) => {
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid request body" });
  const [project] = await db.insert(projectsTable).values(parsed.data).returning();
  res.status(201).json({ ...project, createdAt: project.createdAt.toISOString() });
});

router.delete("/projects/:id", async (req, res) => {
  const parsed = DeleteProjectParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid project ID" });
  const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parsed.data.id));
  if (!project) return res.status(404).json({ error: "Project not found" });
  await db.delete(projectsTable).where(eq(projectsTable.id, parsed.data.id));
  res.status(204).end();
});

router.post("/projects/generate", async (req, res) => {
  const parsed = GenerateProjectBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid request body" });

  const { topic, boardType } = parsed.data;
  const boardLabel = boardType === "esp32" ? "ESP32" : "Arduino";
  const templateHint = getTemplateHint(topic);

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const systemPrompt = `You are a senior embedded systems engineer and university professor specializing in ${boardLabel} and IoT development. 
You have 15+ years of experience designing real-world embedded systems and teaching engineering students.

Your outputs must be:
- Technically accurate with correct pin numbers and GPIO assignments for the ${boardLabel}
- Using real, installable Arduino library names (verify they exist in Arduino Library Manager)
- Complete executable code — never truncate or use placeholder comments like "// add more code here"
- Professional engineering quality with proper code structure, variable naming, and comments
- Appropriate for diploma/engineering students preparing for lab exams and viva

PLATFORM RULES:
${boardType === "esp32" ? `- ESP32 GPIO pins: use GPIO numbers (e.g. GPIO 4, GPIO 16, GPIO 17)
- ESP32 ADC pins: GPIO 32–39 (input only), GPIO 25/26 for DAC
- ESP32 I2C defaults: SDA=GPIO21, SCL=GPIO22
- ESP32 SPI defaults: MOSI=GPIO23, MISO=GPIO19, SCK=GPIO18, CS=GPIO5
- ESP32 PWM: any GPIO via ledcSetup/ledcAttachPin` : `- Arduino Uno pins: D0–D13 digital, A0–A5 analog
- Arduino Uno I2C: SDA=A4, SCL=A5
- Arduino Uno SPI: MOSI=D11, MISO=D12, SCK=D13, SS=D10
- Arduino Uno PWM pins: D3, D5, D6, D9, D10, D11 only
- Arduino Uno 3.3V max 50mA; 5V logic level`}

CODE QUALITY RULES:
- Every variable must be initialized
- Use #define or const for pin numbers and magic values
- All sensor reads must have error/timeout handling
- Use descriptive function names and add block comments
- Code must compile without warnings`;

  const userPrompt = `Generate a COMPLETE professional ${boardLabel} project guide for: "${topic}"${templateHint}

Respond with EXACTLY these 11 sections in order, each with the exact ## heading shown:

## Difficulty Level
State exactly one of: Beginner | Intermediate | Advanced
Then one sentence explaining why.

## Project Overview
3-4 sentences: what the project does, real-world use case, and who benefits from it.

## Required Components
Bulleted list with exact quantities and specifications:
- 1x ${boardLabel} board
- Include voltage ratings, resistance values, module model numbers where relevant

## Required Libraries
List each library with:
- Library name (exact name as it appears in Arduino Library Manager)
- Brief purpose (one line)
- Installation: Tools > Manage Libraries > search "[name]"
If no external libraries needed, state "No external libraries required — uses built-in Arduino functions only."

## Pin Connections
Provide a clean connection table:
Component | Component Pin | ${boardLabel} Pin | Notes
Include voltage levels and any resistor values needed.

## Working Principle
3-5 paragraphs explaining:
1. How each sensor/actuator works physically
2. The signal flow and data processing logic
3. The control algorithm used

## ${boardLabel} Code
Provide complete, compilable, well-commented code:
\`\`\`cpp
// [Project name] - ${boardLabel} Implementation
// [Brief description]
// Libraries: [list]

#include <...>

// Pin definitions
#define ...

// Constants
const ...

// Global variables
...

void setup() {
  // Initialize serial, pins, sensors
}

void loop() {
  // Main logic with comments
}

// Helper functions with comments
\`\`\`

## Code Explanation
Step-by-step walkthrough of the code:
1. Explain each #include and why it's needed
2. Explain pin definitions and constants
3. Walk through setup() function
4. Walk through loop() logic
5. Explain any helper functions

## Troubleshooting Guide
List 4-6 common issues with solutions:
**Issue:** [Description]
**Cause:** [Root cause]
**Solution:** [Step-by-step fix]

## Viva Questions & Answers
Provide 6 exam-quality Q&A pairs:
**Q1:** [Question]
**A:** [Detailed answer with technical depth]

## Circuit Diagram
Draw an ASCII wiring diagram using box-drawing characters (┌─┐│└┘├┤┬┴┼►):
Show the ${boardLabel} board and all components as labeled boxes.
Draw wires with signal labels (VCC, GND, DATA, SDA, SCL, etc.).
Example:
  ┌──────────────┐        ┌──────────────┐
  │   ${boardLabel.padEnd(12)} │        │  COMPONENT   │
  │  5V ─────────┼────────┼── VCC        │
  │  GND ────────┼────────┼── GND        │
  │  D2 ─────────┼────────┼── DATA       │
  └──────────────┘        └──────────────┘
Make the diagram accurate and specific to this project's components.`;

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-4o",
      max_completion_tokens: 8192,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      stream: true,
    });

    let fullResponse = "";
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true, fullResponse })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Error generating project");
    res.write(`data: ${JSON.stringify({ error: "Failed to generate project" })}\n\n`);
    res.end();
  }
});

export default router;
